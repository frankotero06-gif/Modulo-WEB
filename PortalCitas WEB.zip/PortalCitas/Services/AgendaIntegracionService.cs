using System.Net.Http.Json;
using PortalCitas.Models;

namespace PortalCitas.Services;

/// <summary>
/// Implementación real, siguiendo RF-INT-02 del SRS (endpoints con
/// esquemas JSON normalizados). TODO cuando Ricardo confirme el
/// contrato exacto: ajustar rutas y nombres de propiedades de los
/// DTOs de respuesta.
/// </summary>
public class AgendaIntegracionService : IAgendaService
{
    private readonly HttpClient _httpClient;

    public AgendaIntegracionService(HttpClient httpClient) => _httpClient = httpClient;

    public async Task<List<MedicoDto>> ObtenerMedicosAsync()
    {
        // TODO: GET /medicos
        var resultado = await _httpClient.GetFromJsonAsync<List<MedicoDto>>("medicos");
        return resultado ?? new List<MedicoDto>();
    }

    public async Task<List<CitaDto>> ObtenerCitasPacienteAsync(string pacienteId)
    {
        // TODO: GET /pacientes/{id}/citas
        var resultado = await _httpClient.GetFromJsonAsync<List<CitaDto>>($"pacientes/{pacienteId}/citas");
        return resultado ?? new List<CitaDto>();
    }

    public async Task<List<string>> ObtenerHorariosDisponiblesAsync(int medicoId, DateTime fecha)
    {
        // TODO: GET /medicos/{id}/horarios?fecha=yyyy-MM-dd
        var fechaTexto = fecha.ToString("yyyy-MM-dd");
        var resultado = await _httpClient.GetFromJsonAsync<List<string>>($"medicos/{medicoId}/horarios?fecha={fechaTexto}");
        return resultado ?? new List<string>();
    }

    public async Task<ResultadoAgendar> AgendarCitaAsync(string pacienteId, int medicoId, DateTime fecha, string hora, string motivo)
    {
        try
        {
            // TODO: POST /citas
            var respuesta = await _httpClient.PostAsJsonAsync("citas", new
            {
                pacienteId,
                medicoId,
                fecha = fecha.ToString("yyyy-MM-dd"),
                hora,
                motivo
            });

            if (!respuesta.IsSuccessStatusCode)
            {
                return ResultadoAgendar.Fallo("No se pudo agendar la cita. Ese horario podría ya no estar disponible.");
            }

            var cita = await respuesta.Content.ReadFromJsonAsync<CitaDto>();
            return cita is not null
                ? ResultadoAgendar.Ok(cita)
                : ResultadoAgendar.Fallo("Respuesta inesperada del servidor.");
        }
        catch (HttpRequestException)
        {
            return ResultadoAgendar.Fallo("No se pudo conectar con el sistema. Intenta de nuevo en unos minutos.");
        }
    }

    public async Task<bool> CancelarCitaAsync(string pacienteId, int citaId)
    {
        // TODO: confirmar si Ricardo expone esto como DELETE /citas/{id}
        // o como POST /citas/{id}/cancelar
        var respuesta = await _httpClient.PostAsync($"citas/{citaId}/cancelar", null);
        return respuesta.IsSuccessStatusCode;
    }
}
