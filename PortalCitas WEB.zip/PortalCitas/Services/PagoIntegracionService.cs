using System.Net.Http.Json;
using PortalCitas.Models;

namespace PortalCitas.Services;

/// <summary>
/// TODO cuando Ricardo confirme el contrato real de la pasarela de
/// pago (RF-INT-02): ajustar rutas y nombres de propiedades.
/// </summary>
public class PagoIntegracionService : IPagoService
{
    private readonly HttpClient _httpClient;

    public PagoIntegracionService(HttpClient httpClient) => _httpClient = httpClient;

    public async Task<List<FacturaDto>> ObtenerFacturasPacienteAsync(string pacienteId)
    {
        // TODO: GET /pacientes/{id}/facturas
        var resultado = await _httpClient.GetFromJsonAsync<List<FacturaDto>>($"pacientes/{pacienteId}/facturas");
        return resultado ?? new List<FacturaDto>();
    }

    public async Task<FacturaDto?> ObtenerFacturaAsync(string pacienteId, int facturaId)
    {
        // TODO: GET /pacientes/{id}/facturas/{facturaId}
        return await _httpClient.GetFromJsonAsync<FacturaDto>($"pacientes/{pacienteId}/facturas/{facturaId}");
    }

    public async Task<ResultadoPago> PagarFacturaAsync(string pacienteId, int facturaId, string referenciaPasarela)
    {
        try
        {
            // TODO: confirmar con Emilia la ruta exacta y el nombre del campo
            // (aquí asumimos POST /facturas/{id}/pagar con "referenciaPasarela").
            // Los datos de la tarjeta NUNCA salen de IPasarelaService: al
            // CORE solo le llega la referencia que devolvió la pasarela.
            var respuesta = await _httpClient.PostAsJsonAsync($"facturas/{facturaId}/pagar", new
            {
                referenciaPasarela
            });

            if (!respuesta.IsSuccessStatusCode)
            {
                return ResultadoPago.Fallo("El pago no pudo registrarse. Intenta de nuevo.");
            }

            var factura = await respuesta.Content.ReadFromJsonAsync<FacturaDto>();
            return factura is not null
                ? ResultadoPago.Ok(factura)
                : ResultadoPago.Fallo("Respuesta inesperada del servidor.");
        }
        catch (HttpRequestException)
        {
            return ResultadoPago.Fallo("No se pudo conectar con el sistema. Intenta de nuevo en unos minutos.");
        }
    }
}
