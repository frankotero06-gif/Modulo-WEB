(function () {
    const selectMedico = document.getElementById("select-medico");
    const inputFecha = document.getElementById("input-fecha");
    const contenedorHorarios = document.getElementById("horarios-disponibles");
    const inputHora = document.getElementById("input-hora");
    const btnAgendar = document.getElementById("btn-agendar");

    if (!selectMedico || !inputFecha) return;

    async function cargarHorarios() {
        const medicoId = selectMedico.value;
        const fecha = inputFecha.value;

        inputHora.value = "";
        btnAgendar.disabled = true;

        if (!medicoId || !fecha) {
            contenedorHorarios.innerHTML = '<p class="horarios-hint">Selecciona un médico y una fecha para ver los horarios disponibles.</p>';
            return;
        }

        contenedorHorarios.innerHTML = '<p class="horarios-hint">Cargando horarios...</p>';

        try {
            const url = `/Citas/HorariosDisponibles?medicoId=${encodeURIComponent(medicoId)}&fecha=${encodeURIComponent(fecha)}`;
            const respuesta = await fetch(url);
            const horarios = await respuesta.json();

            if (!horarios.length) {
                contenedorHorarios.innerHTML = '<p class="horarios-hint">No hay horarios disponibles ese día. Prueba otra fecha.</p>';
                return;
            }

            contenedorHorarios.innerHTML = "";
            horarios.forEach((hora) => {
                const boton = document.createElement("button");
                boton.type = "button";
                boton.className = "horario-btn";
                boton.textContent = hora;
                boton.addEventListener("click", () => seleccionarHorario(boton, hora));
                contenedorHorarios.appendChild(boton);
            });
        } catch (error) {
            contenedorHorarios.innerHTML = '<p class="horarios-hint">No se pudieron cargar los horarios. Intenta de nuevo.</p>';
        }
    }

    function seleccionarHorario(boton, hora) {
        document.querySelectorAll(".horario-btn").forEach((b) => b.classList.remove("selected"));
        boton.classList.add("selected");
        inputHora.value = hora;
        btnAgendar.disabled = false;
    }

    selectMedico.addEventListener("change", cargarHorarios);
    inputFecha.addEventListener("change", cargarHorarios);
})();
