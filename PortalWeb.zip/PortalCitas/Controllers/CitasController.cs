using Microsoft.AspNetCore.Mvc;
using PortalCitas.Models;
using PortalCitas.Services;

namespace PortalCitas.Controllers;

public class CitasController : PacienteControllerBase
{
    private readonly IAgendaService _agendaService;

    public CitasController(IAgendaService agendaService)
    {
        _agendaService = agendaService;
    }

    // GET /Citas
    public async Task<IActionResult> Index()
    {
        var citas = await _agendaService.ObtenerCitasPacienteAsync(PacienteId);
        ViewBag.Mensaje = TempData["Mensaje"];
        return View(citas);
    }

    // GET /Citas/Agendar
    public async Task<IActionResult> Agendar()
    {
        var modelo = new AgendarCitaViewModel
        {
            Medicos = await _agendaService.ObtenerMedicosAsync(),
        };
        return View(modelo);
    }

    // POST /Citas/Agendar
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Agendar(NuevaCitaInput form)
    {
        if (!ModelState.IsValid)
        {
            var modeloConError = new AgendarCitaViewModel
            {
                Form = form,
                Medicos = await _agendaService.ObtenerMedicosAsync(),
            };
            return View(modeloConError);
        }

        var resultado = await _agendaService.AgendarCitaAsync(
            PacienteId, form.MedicoId, form.Fecha, form.Hora, form.Motivo);

        if (!resultado.Exitoso)
        {
            ModelState.AddModelError(string.Empty, resultado.MensajeError ?? "No se pudo agendar la cita.");
            var modeloConError = new AgendarCitaViewModel
            {
                Form = form,
                Medicos = await _agendaService.ObtenerMedicosAsync(),
            };
            return View(modeloConError);
        }

        TempData["Mensaje"] = $"Cita agendada para el {resultado.Cita!.Fecha:dd/MM/yyyy} a las {resultado.Cita.Hora}.";
        return RedirectToAction(nameof(Index));
    }

    // GET /Citas/HorariosDisponibles?medicoId=1&fecha=2026-09-25
    // Endpoint AJAX que consume wwwroot/js/agendar.js para pintar los
    // botones de horario disponibles sin recargar la página.
    [HttpGet]
    public async Task<IActionResult> HorariosDisponibles(int medicoId, DateTime fecha)
    {
        var horarios = await _agendaService.ObtenerHorariosDisponiblesAsync(medicoId, fecha);
        return Json(horarios);
    }

    // POST /Citas/Cancelar
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Cancelar(int id)
    {
        var ok = await _agendaService.CancelarCitaAsync(PacienteId, id);
        TempData["Mensaje"] = ok ? "Cita cancelada." : "No se pudo cancelar la cita.";
        return RedirectToAction(nameof(Index));
    }
}
