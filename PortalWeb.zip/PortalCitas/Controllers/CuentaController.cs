using Microsoft.AspNetCore.Mvc;
using PortalCitas.Models;
using PortalCitas.Services;

namespace PortalCitas.Controllers;

public class CuentaController : Controller
{
    private readonly IAutenticacionService _autenticacionService;

    public CuentaController(IAutenticacionService autenticacionService)
    {
        _autenticacionService = autenticacionService;
    }

    [HttpGet]
    public IActionResult Login()
    {
        if (!string.IsNullOrEmpty(HttpContext.Session.GetString("PacienteId")))
        {
            return RedirectToAction("Index", "Citas");
        }
        return View(new LoginViewModel());
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginViewModel modelo)
    {
        if (!ModelState.IsValid)
        {
            return View(modelo);
        }

        var resultado = await _autenticacionService.IniciarSesionAsync(modelo.Correo, modelo.Clave);

        if (!resultado.Exitoso)
        {
            ModelState.AddModelError(string.Empty, resultado.MensajeError ?? "Correo o clave incorrectos.");
            return View(modelo);
        }

        HttpContext.Session.SetString("PacienteId", resultado.PacienteId ?? string.Empty);
        HttpContext.Session.SetString("NombrePaciente", resultado.NombrePaciente ?? string.Empty);

        return RedirectToAction("Index", "Citas");
    }

    public IActionResult Salir()
    {
        HttpContext.Session.Clear();
        return RedirectToAction("Login");
    }
}
