using PortalCitas.Models;

namespace PortalCitas.Services;

/// <summary>
/// Cualquier correo/clave no vacíos entran. Activo mientras
/// Integración (Ricardo) no tenga listo el login real.
/// </summary>
public class AutenticacionMockService : IAutenticacionService
{
    public async Task<ResultadoLogin> IniciarSesionAsync(string correo, string clave)
    {
        await Task.Delay(300);

        if (string.IsNullOrWhiteSpace(correo) || string.IsNullOrWhiteSpace(clave))
        {
            return ResultadoLogin.Fallo("Correo o clave incorrectos.");
        }

        return ResultadoLogin.Ok(pacienteId: "1", nombrePaciente: "Juan Pérez");
    }
}
