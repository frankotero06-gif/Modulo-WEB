using System.Net.Http.Json;
using PortalCitas.Models;

namespace PortalCitas.Services;

/// <summary>
/// TODO cuando Ricardo confirme el contrato real:
///   1. Ajustar la ruta "/auth/login".
///   2. Ajustar los nombres de "RespuestaLoginApi".
///   3. Poner la URL real en appsettings.json → "IntegracionApiBaseUrl".
/// </summary>
public class AutenticacionIntegracionService : IAutenticacionService
{
    private readonly HttpClient _httpClient;

    public AutenticacionIntegracionService(HttpClient httpClient) => _httpClient = httpClient;

    public async Task<ResultadoLogin> IniciarSesionAsync(string correo, string clave)
    {
        try
        {
            var respuesta = await _httpClient.PostAsJsonAsync("auth/login", new { correo, clave });
            if (!respuesta.IsSuccessStatusCode)
            {
                return ResultadoLogin.Fallo("Correo o clave incorrectos.");
            }

            var datos = await respuesta.Content.ReadFromJsonAsync<RespuestaLoginApi>();
            if (datos is null)
            {
                return ResultadoLogin.Fallo("Respuesta inesperada del servidor.");
            }

            return ResultadoLogin.Ok(datos.PacienteId, datos.NombrePaciente);
        }
        catch (HttpRequestException)
        {
            return ResultadoLogin.Fallo("No se pudo conectar con el sistema. Intenta de nuevo en unos minutos.");
        }
    }

    private class RespuestaLoginApi
    {
        public string PacienteId { get; set; } = string.Empty;
        public string NombrePaciente { get; set; } = string.Empty;
    }
}
