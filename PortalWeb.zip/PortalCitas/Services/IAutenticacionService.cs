using PortalCitas.Models;

namespace PortalCitas.Services;

public interface IAutenticacionService
{
    Task<ResultadoLogin> IniciarSesionAsync(string correo, string clave);
}
